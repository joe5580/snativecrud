</div>
<script type="text/javascript" src="<?php echo base_url('assest/js/registration-ajax.js')?>"></script>
</body>
</html>