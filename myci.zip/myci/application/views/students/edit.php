<?php
$this->load->model('student_model');
$states = $this->student_model->fetchStates();
$cities = $this->student_model->fetchCities();
$hobbieslist = explode(",", $students->hobbies);
?>
<div class="col-md-8">
<form id="editregister" method="post">
  <div class="form-group">
    <label for="fname">First Name:</label>
    <input type="text" name="fname" value="<?php echo $students->first_name; ?>" class="form-control" id="fname">
  </div>
  <div class="form-group">
    <label for="lname">Last name:</label>
    <input type="text" name="lname" value="<?php echo $students->last_name; ?>" class="form-control" id="lname">
  </div>
  <div class="form-group">
    <label for="email">Email address:</label>
    <input type="email" name="email" class="form-control" value="<?php echo $students->email; ?>" id="email">
  </div>
  <div class="form-group">
    <label for="email">Country</label>
    <select name="slcountry" id="slcountry" class="form-control">
    	<option value="">--Select--</option>
    	<?php
      $select="";
    	foreach($countries as $country) :
        if($students->country_id == $country->c_id){
          $select = "selected";
        }
        else{
          $select  = "";
        }
    	?>
    		<option value="<?php echo $country->c_id ?>" <?php echo $select;?>><?php echo $country->country_name ?></option>
    	<?php endforeach;?>
    </select>
  </div>
  <div class="form-group">
    <label for="email">State</label>
    <select name="slstate" id="slstate" class="form-control">
    	<option value="">--Select--</option>
      <?php
       foreach($states as $state):
        if($students->state_id == $state->s_id){
          $select = "selected";
        }
        else{
          $select  = "";
        }
      ?>
      <option value="<?php echo $state->s_id; ?>" <?php echo $select;?>><?php echo $state->state_name; ?></option>
    <?php endforeach;?>
    </select>
  </div>
  <div class="form-group">
    <label for="email">City</label>
    <select name="slcity" id="slcity" class="form-control">
    	<option value="">--Select--</option>
       <?php
       foreach($cities as $city):
        if($students->city_id == $city->citi_id){
          $select = "selected";
        }
        else{
          $select  = "";
        }
      ?>
      <option value="<?php echo $city->citi_id; ?>" <?php echo $select; ?> ><?php echo $city->city_name; ?></option>
    <?php endforeach;?>
    </select>
  </div>
  <div class="form-group">
    <label for="pwd">Hobbies:</label>
    <input type="checkbox"  id="hobbies" class="chk" value="reading" name="hobbies[]" <?php echo (in_array('reading', $hobbieslist) ? 'checked' : '');?>> Reading
    <input type="checkbox"  id="hobbies" class="chk" value="sports" name="hobbies[]" <?php echo (in_array('sports', $hobbieslist) ? 'checked' : '');?>> Sports
    <input type="checkbox"  id="hobbies" class="chk" value="music" name="hobbies[][" <?php echo (in_array('music', $hobbieslist) ? 'checked' : '');?>> Music
    <input type="checkbox"  id="hobbies" class="chk" value="debat" name="hobbies[]" <?php echo (in_array('debat', $hobbieslist) ? 'checked' : '');?>> Debat
  </div>
  <div class="form-group">
    <label for="pwd">Status</label>
    <div class="checkbox">
        <label><input type="radio" name="txtstatus" value="1" <?php echo ($students->status == '1') ? 'checked' : '';?>> Active</label>
       <label><input type="radio" name="txtstatus" value="0" <?php echo ($students->status == '0') ? 'checked' : '';?>> Deactive</label>
    </div>
  </div>
  <input type="hidden" value="<?php echo $students->user_id; ?>" name="editId" id="editId">
  <button type="button" class="btn btn-default" id="btnedit">Submit</button>
</form>
</div>