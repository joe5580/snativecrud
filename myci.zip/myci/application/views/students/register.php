<div class="col-md-8">
<form id="myregister" method="post">
  <div class="form-group">
    <label for="fname">First Name:</label>
    <input type="text" name="fname" class="form-control" id="fname">
  </div>
  <div class="form-group">
    <label for="lname">Last name:</label>
    <input type="text" name="lname" class="form-control" id="lname">
  </div>
  <div class="form-group">
    <label for="email">Email address:</label>
    <input type="email" name="email" class="form-control" id="email">
  </div>
  <div class="form-group">
    <label for="email">Country</label>
    <select name="slcountry" id="slcountry" class="form-control" name="country_id">
    	<option value="">--Select--</option>
    	<?php
    	foreach($countries as $country) :
    	?>
    		<option value="<?php echo $country->c_id ?>"><?php echo $country->country_name ?></option>
    	<?php endforeach;?>
    </select>
  </div>
  <div class="form-group">
    <label for="email">State</label>
    <select name="slstate" id="slstate" class="form-control" name="state_id">
    	<option value="">--Select--</option>
    </select>
  </div>
  <div class="form-group">
    <label for="email">City</label>
    <select name="slcity" id="slcity" class="form-control" name="city_id">
    	<option value="">--Select--</option>
    </select>
  </div>
  <div class="form-group">
    <label for="pwd">Hobbies:</label>
    <input type="checkbox"  id="hobbies" value="reading" name="hobbies[]" class="chk"> Reading
    <input type="checkbox"  id="hobbies" value="sports" name="hobbies[]" class="chk"> Sports
    <input type="checkbox"  id="hobbies" value="music" name="hobbies[][" class="chk"> Music
    <input type="checkbox"  id="hobbies" value="debat" name="hobbies[]" class="chk"> Debat
  </div>
  <div class="form-group">
    <label for="pwd">Status</label>
    <div class="checkbox">
        <label><input type="radio" name="txtstatus" value="1" checked> Active</label>
       <label><input type="radio" name="txtstatus" value="0"> Deactive</label>
    </div>
  </div>
  <button type="button" class="btn btn-default" id="btnsave">Submit</button>
</form>
</div>