<?php

class Student_model extends CI_Model
{
	
	function __construct()
	{
		$this->table = "tbl_user";
	}

	// Get users
	function getStudents(){
		$this->db->select('tbl_user.*,countries.country_name,states.state_name,citis.city_name');
		$this->db->from('tbl_user');
		$this->db->join('countries','tbl_user.country_id = countries.c_id');
		$this->db->join('states','tbl_user.state_id = states.s_id');
		$this->db->join('citis','tbl_user.city_id = citis.citi_id');
		return $this->db->get()->result();
	}

	function removeUser($userID){
		$this->db->where('user_id',$userID);
		return $this->db->delete($this->table);
	}

	//Countries get
	function getCountries(){
		$this->db->select("*");
		$this->db->from("countries");
		return $this->db->get()->result();
	}

	//States get
	function getStates($cid){
		$this->db->select("*");
		$this->db->from("states");
		$this->db->where("country_id",$cid);
		return $this->db->get()->result();
	}

	//Cities get
	function getCities($sid){
		$this->db->select("*");
		$this->db->from("citis");
		$this->db->where("state_id",$sid);
		return $this->db->get()->result();
	}

	function fetchStates(){
		$this->db->select("*");
		$this->db->from("states");
		return $this->db->get()->result();
	}

	function fetchCities(){
		$this->db->select("*");
		$this->db->from("citis");
		return $this->db->get()->result();
	}

	function getAllStudents($uid){
		$this->db->select('tbl_user.*,countries.country_name,states.state_name,citis.city_name');
		$this->db->from('tbl_user');
		$this->db->join('countries','tbl_user.country_id = countries.c_id');
		$this->db->join('states','tbl_user.state_id = states.s_id');
		$this->db->join('citis','tbl_user.city_id = citis.citi_id');
		$this->db->where("tbl_user.user_id",$uid);
		return $this->db->get()->row();
	}

	// Add records
	function saveRecord($postdatas){
		return $this->db->insert($this->table,$postdatas);
	}

	// Edit user by ID
	function updateRecord($postdatas,$uid){
		$this->db->where("user_id",$uid);
		return $this->db->update($this->table,$postdatas);
	}

}