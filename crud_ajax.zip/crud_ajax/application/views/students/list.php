<div class="row">
  	<div class="col-lg-12 margin-tb">
  	  <div class="pull-left">
  	    <h2>My CRUD</h2>
  	  </div>
  	  <div class="pull-right">
  	  	<a href="<?php echo base_url("index.php/registration/registar")?>" class="btn btn-success">Add New</a>  	    
  	  </div>
  	</div>
</div>

<table class="table table-bordered" border="1" id="tbl">
	<tr>
		<th>Fname</th>
		<th>Lname</th>
		<th>Email</th>
		<th>Country</th>
		<th>State</th>
		<th>City</th>
		<th>Hobbies</th>
		<th>Action</th>
	</tr>
	<?php
	if(count($students) > 0) :
		foreach ($students as $key => $value) :
		?>
		<tr class="<?php echo $value->user_id ?>">
			<td><?php echo $value->first_name;?></td>
			<td><?php echo $value->last_name;?></td>
			<td><?php echo $value->email;?></td>
			<td><?php echo $value->country_name;?></td>
			<td><?php echo $value->state_name;?></td>
			<td><?php echo $value->city_name;?></td>
			<td><?php echo $value->hobbies;?></td>
			<td><a href="<?php echo base_url("index.php/registration/edit/{$value->user_id}")?>">Edit</a> | <a href="#" class="deleteuser" data-user="<?php echo $value->user_id ?>">Delete</a></td>
		</tr>
	<?php endforeach; else :?>
	<tr><td colspan="8">No users found</td></tr> 
<?php endif;?>
</table>