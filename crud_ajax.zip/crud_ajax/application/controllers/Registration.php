<?php

defined('BASEPATH') OR exit('No direct script access allowed');


class Registration extends CI_Controller {


   /**

    * Get All Data from this method.

    *

    * @return Response

   */

   public function __construct(){
      parent::__construct();
      $this->load->model('student_model');
   }

   public function index()
   {

      $data = [];

      $data['students'] = $this->student_model->getStudents();

      $this->load->view('students/header');
      $this->load->view('students/list',$data);
      $this->load->view('students/footer');

   }

   // Registration form

   public function registar(){
      $data = [];

      $data['countries'] = $this->student_model->getCountries();

      $this->load->view('students/header');
      $this->load->view('students/register',$data);
      $this->load->view('students/footer');
   }

   // Get states by country
   public function statelist(){
      $countid = $this->input->post('countryid'); 

      $stateslists = $this->student_model->getStates($countid);
      //print_r($stateslists);exit;
      if($stateslists){
        $option = "<option value=''>--Select--</option>";
        foreach ($stateslists as $key => $value) {
          $option.="<option value='{$value->s_id}'>";
          $option.=$value->state_name;
          $option.="</option>";
        }
        echo json_encode(array('status' => '1',"data" => $option));
      }
      else{
        echo json_encode(array("status" => "0"));
      }
   }

   // Get states by country
   public function citylist(){
      $stateid = $this->input->post('stateid'); 

      $citislists = $this->student_model->getCities($stateid);
      //print_r($stateslists);exit;
      if($citislists){
        $option = "<option value=''>--Select--</option>";
        foreach ($citislists as $key => $value) {
          $option.="<option value='{$value->citi_id}'>";
          $option.=$value->city_name;
          $option.="</option>";
        }
        echo json_encode(array('status' => '1',"data" => $option));
      }
      else{
        echo json_encode(array("status" => "0"));
      }
   }


   /**

    * Store Data from this method.

    *

    * @return Response

   */

   public function addrecord()
   {

      // code for insert records
      if($this->input->post()){
          $data = array(
            "first_name" => $this->input->post('fname'),
            "last_name" => $this->input->post('lname'),
            "email" => $this->input->post('email'),
            "country_id" => $this->input->post('slcountry'),
            "state_id" => $this->input->post('slstate'),
            "city_id" => $this->input->post('slcity'),
            "hobbies" => implode(",", $this->input->post('hobi')),
            "status" => $this->input->post('ustatus'),
          );


          $added = $this->student_model->saveRecord($data);

          if($added){
            echo json_encode(array("status"=>"1"));
          }
          else{
            echo json_encode(array("sttaus" => "0"));
          }
          exit;
      }

   }


   /**

    * Edit Data from this method.

    *

    * @return Response

   */

   public function edit($id)
   {
      $data = [];

      $data['students'] = $this->student_model->getAllStudents($id);
      $data['countries'] = $this->student_model->getCountries();
      $this->load->view('students/header');
      $this->load->view('students/edit',$data);
      $this->load->view('students/footer');

   }


   /**

    * Update Data from this method.

    *

    * @return Response

   */

   public function update()
   {
    $eID = $this->input->post('editID');
      if(!empty($this->input->post('hobi'))){
        $hobby = implode(",", $this->input->post('hobi'));
      }  else{
        $hobby = '';
      }
    // code for insert records
      if($this->input->post()){
          $data = array(
            "first_name" => $this->input->post('fname'),
            "last_name" => $this->input->post('lname'),
            "email" => $this->input->post('email'),
            "country_id" => $this->input->post('slcountry'),
            "state_id" => $this->input->post('slstate'),
            "city_id" => $this->input->post('slcity'),
            "hobbies" => $hobby,
            "status" => $this->input->post('ustatus'),
          );


          $added = $this->student_model->updateRecord($data,$eID);
          
          if($added){
            echo json_encode(array("status"=>"1"));
          }
          else{
            echo json_encode(array("sttaus" => "0"));
          }
          exit;
      }

   }

   /**

    * Delete Data from this method.

    *

    * @return Response

   */

   public function delete()
   {

      $userid = $this->input->post('user');

      $deleted = $this->student_model->removeUser($userid);

      if($deleted){
        echo json_encode(array("status" => '1'));
      }
      else{
        echo json_encode(array("status" => '0'));
      }
      exit;
    }


}