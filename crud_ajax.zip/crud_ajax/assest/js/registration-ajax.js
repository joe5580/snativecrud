$(document).ready(function(){

    // Validation tu karai deje


    // States by country

    $("#slcountry").on('change',function(){
        var cnid = $(this).val();
        $.ajax({
            type:"POST",
            url:"http://localhost/crud_ajax/index.php/registration/statelist", // dynamic kari deje ha
            dataType:"json",
            data:{countryid:cnid},
            success: function(data){
                if(data.status == '1'){
                    $("#slstate").html(data.data);
                }
                else{
                    $("#slstate").html("<option value=''>--Select--</option>");
                    $("#slcity").html("<option value=''>--Select--</option>");
                }
            }
        })
    })

    // Cities by state

    $("#slstate").on('change',function(){
        var stid = $(this).val();
        $.ajax({
            type:"POST",
            url:"http://localhost/crud_ajax/index.php/registration/citylist", // dynamic kari deje ha
            dataType:"json",
            data:{stateid:stid},
            success: function(data){
                if(data.status == '1'){
                    $("#slcity").html(data.data);
                }
            }
        })
    })

    // Save data
    $("#btnsave").on('click',function(e){

        var flag = 1;
        var fname = $("#fname").val();
        var lname = $("#lname").val();
        var email = $("#email").val();
        var slcountry = $("#slcountry").val();
        var slstate = $("#slstate").val();
        var slcity = $("#slcity").val();
        var ustatus = $("input[name='txtstatus']:checked").val();
        var hobi = [];
        //var chkArray = [];
        
        // Look for all checkboxes that have a specific class and was checked
        $(".chk:checked").each(function() {
            hobi.push($(this).val());
        });

        if(flag == 0){ // validation check
            e.preventDefault();
        }
        else{
            // ajax for insert
            $.ajax({
                type:"POST",
                url:"http://localhost/crud_ajax/index.php/registration/addrecord", // dynamic kari deje ha
                dataType:"json",
                data:{fname:fname,lname:lname,email:email,slcountry:slcountry,slstate:slstate,slcity:slcity,ustatus:ustatus,hobi:hobi},
                success: function(data){
                    if(data.status == '1'){
                        alert("Student record inserted successfully")
                        $("#myregister")[0].reset();
                        setTimeout(function(){ window.location="http://localhost/crud_ajax/index.php/registration" }, 1000);
                        
                    }
                    else{
                        alert("Error to insert record");    
                    }
                }
            })
        }
    });

    // Save data
    $("#btnedit").on('click',function(e){

        var flag = 1;
        var editID = $("#editId").val();
        var fname = $("#fname").val();
        var lname = $("#lname").val();
        var email = $("#email").val();
        var slcountry = $("#slcountry").val();
        var slstate = $("#slstate").val();
        var slcity = $("#slcity").val();
        var ustatus = $("input[name='txtstatus']:checked").val();
        var hobi = [];
        //var chkArray = [];
        
        // Look for all checkboxes that have a specific class and was checked
        $(".chk:checked").each(function() {
            hobi.push($(this).val());
        });
       
        if(flag == 0){ // validation check
            e.preventDefault();
        }
        else{
            // ajax for insert
            $.ajax({
                type:"POST",
                url:"http://localhost/crud_ajax/index.php/registration/update", // dynamic kari deje ha
                dataType:"json",
                data:{editID:editID,fname:fname,lname:lname,email:email,slcountry:slcountry,slstate:slstate,slcity:slcity,ustatus:ustatus,hobi:hobi},
                success: function(data){
                    if(data.status == '1'){
                        alert("Student record updated successfully")
                        $("#myregister")[0].reset();
                        setTimeout(function(){ window.location="http://localhost/crud_ajax/index.php/registration" }, 1000);
                        
                    }
                    else{
                        alert("Error to update record");    
                    }
                }
            })
        }
    });


    // Delete Record

    $(".deleteuser").on('click',function(e){
        var uid = $(this).attr('data-user');

        if(confirm('Are you sure ?')){
            $.ajax({
                type:"POST",
                url:"http://localhost/crud_ajax/index.php/registration/delete", // dynamic kari deje ha
                dataType:"json",
                data:{user:uid},
                success: function(data){
                    if(data.status == '1'){
                        $("#tbl ."+uid).remove();
                    }
                }
            })
        }
    })
})